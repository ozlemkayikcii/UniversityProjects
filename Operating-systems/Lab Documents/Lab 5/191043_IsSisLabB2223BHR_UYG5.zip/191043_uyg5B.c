#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <sys/wait.h>
#include <unistd.h>
#include <pthread.h>

/**
 * @brief 
 * body numaralandırma türü, NUMOFITEMS sabiti, bir pthread_mutex_t tipinde bir mutex, bir count değişkeni ve altı adet sem_t tipinde semafor tanımlarını içerir.

 * body numaralandırma türü, HEAD, UBDY, HAND, LEG_ ve FOOT olmak üzere beş farklı üyeden oluşur.

 * NUMOFITEMS sabiti, 13 olarak tanımlanmış bir sayıdır.

 * pthread_mutex_t tipindeki mtx, bir mutex (kilit) nesnesidir.

 * count değişkeni, başlangıçta sıfır olarak tanımlanmış bir tamsayıdır.

 * sem_t tipindeki smph1, smph2, smph3, smph4, smph5 ve smph6, altı adet semafor nesnesini temsil eder.
 */
enum body {HEAD, UBDY, HAND, LEG_, FOOT};

#define NUMOFITEMS 13
pthread_mutex_t mtx;

int count = 0;

sem_t smph1, smph2, smph3, smph4, smph5, smph6; 

/**
 * @brief Giysi öğesi giyme işlemini gerçekleştirir. 
 *  Fonksiyonun işlevi, giysi öğesini belirtilen vücut bölümüne giydirmek ve ilgili çıktıyı ekrana yazdırmaktır.
 * @param part part Vücut bölümünü temsil eden bir sayı.
 * @param name Öğenin adı.
 */
void dressItem(int part, char* name) 
{

    static const char* BODY_STRING[] = { "kafa ", "govde", "el   ", "bacak", "ayak " };

    if (count == 0) //ilk işlem gerçekleşir.
    {

        printf("%2d. \t\t\t\t\t--> Saglik calisanlarina sonsuz tesekkurler!..\n", count);
        count++;
    }
    printf("%2d. (%s) %s ", count, BODY_STRING[part], name);

    if (count == 13) //son işlem gerçekleşir.
    { 
        printf("\t--> Goreve hazirim!\n");
    }

    else if (count > 6) //count değeri 6 dan büyükse kalan öğe sayısını yazdırma ve eksiltme işlemi başlar.
    {

        printf("\t--> Kalan oge sayisi: %2d\n", 13 - count);
        count++;
    }

    else 
    {

        printf("\n"); //ilk, son veya 6 sayısından büyük değilse count 1 arttırılır.
        count++;
    }


}
/**
 * @brief "HEAD" vücut bölümü için giysi öğelerini giydirme işlemini gerçekleştirir.
 * 
 * @param p p İş parçacığı için bir işaretçi.
 * @return void* İş parçacığı sonucu.
 */
void* funcHEAD(void* p) 
{
    sem_wait(&smph4);                 //smph4 semaforuna bekleniyor.
    pthread_mutex_lock(&mtx);         //Mutex (mtx) kilidi alınıyor.

    dressItem(0, "YuzDezenfektani          "); //dressItem fonksiyonu çağrılarak "Yüz Dezenfektanı" giysi öğesi giydiriliyor.

    pthread_mutex_unlock(&mtx);         //Mutex kilidi serbest bırakılıyor.
    sem_wait(&smph2);                   //smph2 semaforuna bekleniyor.

    dressItem(0, "SaglikMaskesi            ");   //dressItem fonksiyonu çağrılarak "Sağlık Maskesi" ve "Bone" giysi öğeleri giydiriliyor.
    dressItem(0, "Bone                     ");

    sem_post(&smph3);                            //smph3 semaforu işaretleniyor.

    sem_wait(&smph4);                           //smph4 semaforuna bekleniyor.

    dressItem(0, "KoruyucuPlastikYuzMaskesi"); //dressItem fonksiyonu çağrılarak "Koruyucu Plastik Yüz Maskesi" giysi öğesi giydiriliyor.

}
/**
 * @brief "UBDY" vücut bölümü için giysi öğelerini giydirme işlemini gerçekleştirir.
 * 
 * @param p İş parçacığı için bir işaretçi.
 * @return void* İş parçacığı sonucu.
 */

void* funcUBDY(void* p)
 {
    dressItem(1, "Atlet                    ");
    dressItem(1, "Gomlek                   ");

    sem_wait(&smph3);

    dressItem(1, "Tulum                    ");

    sem_post(&smph4);
}
/**
 * @brief "HAND" vücut bölümü için giysi öğelerini giydirme işlemini gerçekleştirir.
 * 
 * 
 * @param p İş parçacığı için bir işaretçi.
 * @return void* İş parçacığı sonucu.
 */
void* funcHAND(void* p) 
{
    sem_wait(&smph5);
    pthread_mutex_lock(&mtx);

    dressItem(2, "ElDezenfektani           ");
    dressItem(2, "Eldiven                  ");

    pthread_mutex_unlock(&mtx);

    sem_post(&smph2);
}
/**
 * @brief "LEG_" vücut bölümü için giysi öğelerini giydirme işlemini gerçekleştirir.
 * 
 * @param p İş parçacığı için bir işaretçi.
 * @return void* İş parçacığı sonucu.
 */
void* funcLEG_(void* p) 
{
    sem_wait(&smph1);

    dressItem(3, "Pantolon                 ");
    dressItem(3, "Kemer                    ");

    sem_post(&smph6);
}
/**
 * @brief "FOOT" vücut bölümü için giysi öğelerini giydirme işlemini gerçekleştirir.
 * 
 * 
 * @param p İş parçacığı için bir işaretçi.
 * @return void* İş parçacığı sonucu.
 */
void* funcFOOT(void* p) 
{
    dressItem(4, "Corap                    ");

    sem_post(&smph1);
    sem_wait(&smph6);

    dressItem(4, "Ayakkabi                 ");

    sem_post(&smph4);
    sem_post(&smph5);
}
/**
 * @brief Programın başlangıç noktasıdır.
 * sem_init fonksiyonlarıyla semaforların başlatıldığını, 
 * pthread_create fonksiyonlarıyla iş parçacıklarının oluşturulduğunu
 *  ve pthread_join fonksiyonlarıyla iş parçacıklarının tamamlanmasını beklediğini belirtir.
 * @param argc Komut satırı argümanlarının sayısı.
 * @param argv Komut satırı argümanlarının dizisi.
 * @return int Programın dönüş değeri.
 */
int main(int argc, char* argv[]) 
{

    pthread_t kafa, govde, el, bacak, ayak;

    sem_init(&smph1, 0, 0);
    sem_init(&smph2, 0, 0);
    sem_init(&smph3, 0, 0);
    sem_init(&smph4, 0, 0);
    sem_init(&smph5, 0, 0);
    sem_init(&smph6, 0, 0);

    pthread_create(&govde, NULL, funcHEAD, NULL);
    pthread_create(&ayak, NULL, funcUBDY, NULL);
    pthread_create(&bacak, NULL, funcHAND, NULL);
    pthread_create(&kafa, NULL, funcLEG_, NULL);
    pthread_create(&el, NULL, funcFOOT, NULL);

    pthread_join(govde, NULL);
    pthread_join(ayak, NULL);
    pthread_join(bacak, NULL);
    pthread_join(kafa, NULL);
    pthread_join(el, NULL);

    return 0;
}