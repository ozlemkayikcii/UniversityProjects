#include <stdio.h>

/// @brief Bu fonksiyon aldığı sayı değerinin asal olup olmadığını, ve aynı sebepten 1 sayısından kucuk olup olmadığını kontrol eder
/// @param num integer değerindeki bu sayının asal olup olmadığını kontrol eder.
/// @return integer return değeri ile kontrol sağlanmıştır, 1 dönmesi durumu asal olduğunu gösterir.
int is_prime(int num) 
{
    if (num <= 1) 
    {
        return -1;     // 1 sayısından küçük asal sayı yoktur,fonksiyon -1 döndürür.
    }
    for (int i = 2; i * i <= num; i++) 
    {
        if (num % i == 0) 
        {
            return 0;  //sayısının tam böleni varsa , sayı asal değildir.
        }
    }
    return 1;          //sayı asaldır.
}

/// @brief bu foksiyon aldığı parametreden küçük ,en büyük asal sayı değerini döndürür.
/// @param num kendinden küçük ,en büyük asal sayı değerininin bulunmasını istenilen kullanıcı tarafından girilen sayıdır.
void find_max_prime(int num)
{
    int max_prime = num - 1;    //girilen sayı birer birer azaltılarak kontrol edilir.
    while (!is_prime(max_prime))
    {
        max_prime--;
    }
    printf("\n%d sayisindan kucuk, en buyuk asal sayi: %d \n", num, max_prime);
}
/// @brief bu foksiyon aldığı parametreden büyük ,en küçük asal sayı değerini döndürür.
/// @param num kendinden büyük ,en küçük asal sayı değerininin bulunmasını istenilen kullanıcı tarafından girilen sayıdır.
void find_min_prime(int num)
{
    int min_prime = num + 1;   //girilen sayı birer birer arttırılarak kontrol edilir.
    while (!is_prime(min_prime))
    {
        min_prime++;
    }
    printf("%d sayisindan buyuk, en kucuk asal sayi: %d \n", num, min_prime);
}

/// @brief Kullanıcıdan sayı istenir, sayının negatif, 0 ve 1 değerlerinin yanında herhangi bir char karakterinin almaması kontrol edilir.

int main()
{
     int num=0;
      
     while (num < 2 )
     {
         printf("lutfen 1 sayisindan buyuk bir sayi girin: ");
         while (scanf("%u", &num) != 1) 
         {
             printf("\nGecersiz giris, harf girmeden yalnızca sayi girerek lutfen tekrar deneyin: ");
             while (getchar() != '\n');        // input buffer temizleniyor.
         }
     }
   
   
     find_max_prime(num);
     find_min_prime(num);

    return 0;
}


