# tempFiles klasörünü oluştur eğer zaten varsa içeriği temizler.
if [ ! -d "tempFiles" ]; then
    mkdir tempFiles
else
    rm -rf tempFiles/*
fi

#listeleme işlemini başlatır.
ls -alR

# .c ve .sh uzantılı tüm dosyaları tempFiles klasörüne taşır.
find . -name "*.sh" -o -name "*.c" | xargs -I {} mv {} tempFiles
ls -alR

# çalışma klasörü altındaki belirtilen klasör dışındaki tüm dosyaları siler
find . -type f | grep -v ./tempFiles |xargs rm
ls -alR

# tempFiles klasöründeki tüm dosyaları çalışma yolu altına kopyalar.
cp -r tempFiles/* .
ls -alR

# tempFiles klasörünü siler.
rm -rf tempFiles
ls -alR

# kaynak kodu derle
gcc 152120191043_uyg1B.c -o 152120191043_uyg1B.out

# programı çalıştırır ve hemen sonra çıktıyı .txt dosyasına yönlendirir.
echo "bir sayi giriniz: "
./152120191043_uyg1B.out> 152120191043_uyg1B_output.txt

# çıktı dosyasındaki karakter sayısını ekrana yazdırır.
echo "Çikti dosyasindaki karakter sayisi: $(wc -c <152120191043_uyg1B_output.txt)"

# çıktı dosyasının tüm içeriğini ekrana yazdırır.
cat 152120191043_uyg1B_output.txt
